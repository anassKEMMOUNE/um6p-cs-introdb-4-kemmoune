DELETE FROM Facture;
DELETE FROM Commande;
DELETE FROM ChefDeProjet;
DELETE FROM entite;
DELETE FROM fournisseur;



