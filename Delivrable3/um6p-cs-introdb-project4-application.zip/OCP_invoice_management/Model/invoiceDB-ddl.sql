DROP DATABASE IF EXISTS invoiceDb;

CREATE DATABASE invoiceDb;

USE invoiceDb;
DROP TABLE IF EXISTS users;

CREATE TABLE users (
  username VARCHAR(50) NOT NULL PRIMARY KEY,
  email VARCHAR(100) NOT NULL,
  password VARCHAR(100) NOT NULL
);


