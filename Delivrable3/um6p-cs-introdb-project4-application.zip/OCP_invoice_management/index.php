<?php

header("Location: View/login.html");

?>